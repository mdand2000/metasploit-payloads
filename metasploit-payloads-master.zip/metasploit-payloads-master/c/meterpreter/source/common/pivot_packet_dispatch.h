#ifndef _METERPRETER_PIVOT_PACKET_DISPATCH
#define _METERPRETER_PIVOT_PACKET_DISPATCH

DWORD pivot_packet_dispatch(PivotContext* pivotCtx, LPBYTE packetBuffer, DWORD packetSize);

#endif