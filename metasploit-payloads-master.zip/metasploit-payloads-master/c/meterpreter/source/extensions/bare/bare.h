/*!
 * @file bare.h
 * @brief Entry point and intialisation declrations for the bare extention.
 */
#ifndef _METERPRETER_SOURCE_EXTENSION_BARE_BARE_H
#define _METERPRETER_SOURCE_EXTENSION_BARE_BARE_H

#define TLV_TYPE_EXTENSION_BARE	0

// Custom TLVs go here

#endif
