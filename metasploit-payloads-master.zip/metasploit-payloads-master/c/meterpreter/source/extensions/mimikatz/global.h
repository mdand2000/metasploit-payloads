#include <sstream>

extern std::wostringstream oss;
extern std::wostringstream *outputStream;