/*!
 * @file powershell_runner.h
 * @brief This file is generated, do not modify directly.
 */

#ifndef _METERPRETER_SOURCE_EXTENSION_POWERSHELL_RUNNER_H
#define _METERPRETER_SOURCE_EXTENSION_POWERSHELL_RUNNER_H

#define PSHRUNNER_DLL_LEN 31232

extern unsigned char PowerShellRunnerDll[PSHRUNNER_DLL_LEN];

#endif
