#ifndef _METERPRETER_SOURCE_EXTENSION_ESPIA_ESPIA_SERVER_VIDEO_H
#define _METERPRETER_SOURCE_EXTENSION_ESPIA_ESPIA_SERVER_VIDEO_H

DWORD request_video_get_dev_image(Remote *remote, Packet *packet);

#endif
