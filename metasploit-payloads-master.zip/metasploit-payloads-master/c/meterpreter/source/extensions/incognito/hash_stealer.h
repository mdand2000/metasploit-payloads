#ifndef INC_HASH_STEALER_H
#define INC_HASH_STEALER_H

DWORD request_incognito_snarf_hashes(Remote *remote, Packet *packet);

#endif