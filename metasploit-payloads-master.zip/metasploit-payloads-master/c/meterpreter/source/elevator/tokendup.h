#ifndef _METERPRETER_SOURCE_ELEVATOR_TOKENDUP_H
#define _METERPRETER_SOURCE_ELEVATOR_TOKENDUP_H

BOOL elevator_tokendup( DWORD dwThreadId, DWORD dwSecurityRID );

#endif
